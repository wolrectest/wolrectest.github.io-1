<?php 
// $conn=mysqli_connect('localhost','root','','dronex'); 
$conn=mysqli_connect('localhost','root','','wolrec');
?>